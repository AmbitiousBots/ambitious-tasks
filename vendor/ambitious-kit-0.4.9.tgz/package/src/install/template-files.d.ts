export type TemplateFiles = ReadonlyMap<string, string>;
export declare const parseTemplateFiles: (value: unknown) => TemplateFiles;
export declare const templateDirectory: (home: string) => string;
export declare const fixturesDirectory: (home: string) => string;
export declare const placeTemplateFiles: (home: string, files: TemplateFiles) => string;
