import { join } from "node:path";
import { placeTemplateFiles, templateDirectory } from "./template-files.js";
import { sha256Of } from "./text-file.js";
const fileOf = (name) => `skills/${name}.md`;
export const skillsDirectory = (home) => join(templateDirectory(home), "skills");
export const placeSkillFiles = (home, skills) => {
    const root = placeTemplateFiles(home, new Map(skills.map(({ name, body }) => [fileOf(name), body])));
    return skills.map(({ name, description, body }) => ({ name, description, path: join(root, fileOf(name)), sha256: sha256Of(body), bytes: Buffer.byteLength(body, "utf8") }));
};
