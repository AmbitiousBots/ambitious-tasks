import type { TemplateSkill } from "../domain/template-skills.ts";
export type SkillFile = {
    readonly name: string;
    readonly description: string;
    readonly path: string;
    readonly sha256: string;
    readonly bytes: number;
};
export declare const skillsDirectory: (home: string) => string;
export declare const placeSkillFiles: (home: string, skills: readonly TemplateSkill[]) => readonly SkillFile[];
