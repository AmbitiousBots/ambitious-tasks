import { type Fetchers } from "./release.ts";
export type TemplateStatus = {
    readonly update: "current";
} | {
    readonly update: "available";
    readonly latest: string;
} | {
    readonly update: "not checked";
    readonly why: string;
};
export declare const templateStatus: (own: string, mirror: string | null, fetchers?: Fetchers) => Promise<TemplateStatus>;
export declare const templateNote: (own: string, status: TemplateStatus) => string | null;
