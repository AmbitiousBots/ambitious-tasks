import { isNewerVersion } from "../domain/lock.js";
import { latestInstallerVersion, networkFetchers } from "./release.js";
const reason = (error) => (error instanceof Error ? error.message : String(error));
export const templateStatus = async (own, mirror, fetchers = networkFetchers) => {
    try {
        const latest = await latestInstallerVersion(mirror, fetchers);
        return latest !== null && isNewerVersion(latest, own) ? { update: "available", latest } : { update: "current" };
    }
    catch (error) {
        return { update: "not checked", why: `Could not look for a newer template release: ${reason(error)}.` };
    }
};
export const templateNote = (own, status) => {
    if (status.update === "available") {
        return `A newer template is available: release ${status.latest}, and this installer is ${own}. Update the bot's template to get it. Nothing from the newer release was downloaded, installed or run.`;
    }
    if (status.update === "not checked")
        return `${status.why} The pins that came with this installer were used.`;
    return null;
};
