import { parseRoutineOffers, type RoutineFinding, type TemplateRoutine } from "../domain/routines.ts";
export type RoutinesReport = {
    readonly state: "checked" | "not checked";
    readonly routines: readonly (RoutineFinding & {
        readonly proposed: string;
    })[];
    readonly messages: readonly string[];
};
export declare const proposedRoutineFile: (name: string) => string;
export declare const proposedRoutinePath: (home: string, name: string) => string;
export declare const routineOffersIn: (file: string) => ReturnType<typeof parseRoutineOffers>;
export declare const checkRoutines: (file: string | null, home: string, template: readonly TemplateRoutine[]) => RoutinesReport;
