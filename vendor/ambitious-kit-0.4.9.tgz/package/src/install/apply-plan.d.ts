import { SELF_WRITE, type FailedApply, type MergeOutcome, type PlanAction, type PlanTrust, type RestoredOver, type RoutinePlan } from "../domain/apply-plan.ts";
import { type InstructionsCatalogue, type InstructionsFinding, type PermissionChange, type SelfApply } from "../domain/instructions.ts";
import type { LineChange, LineConflict } from "../domain/merge-lines.ts";
import { type TemplateRoutine } from "../domain/routines.ts";
import { type Fingerprint, type TextMatch } from "../domain/whitespace.ts";
import { type InstructionsMerge } from "./instructions-merge.ts";
export type ApplyPlanRequest = {
    readonly home: string;
    readonly currentFile: string;
    readonly publishedFile: string;
    readonly publishedSha256: string;
    readonly routinesFile: string | null;
    readonly readBackFile: string | null;
};
type Planned = Fingerprint & {
    readonly source: "published" | "merged";
    readonly text: string;
};
type PlannedRoutine = RoutinePlan & Fingerprint & {
    readonly proposed: string;
    readonly presentSha256: string | null;
};
export type ApplyPlan = {
    readonly action: PlanAction;
    readonly selfApply: SelfApply;
    readonly reasons: readonly string[];
    readonly trust: PlanTrust;
    readonly write: typeof SELF_WRITE;
    readonly instructions: {
        readonly action: PlanAction;
        readonly current: Fingerprint & {
            readonly state: InstructionsFinding["state"];
            readonly version: number | null;
            readonly match: TextMatch | null;
        };
        readonly published: {
            readonly version: number | null;
            readonly sha256: string;
        };
        readonly planned: Planned | null;
        readonly restoredOver: RestoredOver | null;
        readonly damagedFrom: number | null;
        readonly failedApply: FailedApply | null;
    };
    readonly permissions: (PermissionChange & {
        readonly statement: string;
    }) | null;
    readonly merge: {
        readonly state: MergeOutcome;
        readonly base: InstructionsMerge["base"];
        readonly localChangesKept: readonly LineChange[];
        readonly conflicts: readonly LineConflict[];
    };
    readonly routines: {
        readonly state: "checked" | "not checked";
        readonly routines: readonly PlannedRoutine[];
    };
    readonly previous: Fingerprint & {
        readonly version: number | null;
        readonly file: string;
        readonly keepAs: string;
        readonly archiveFirst: boolean;
    };
    readonly readBack: (Fingerprint & {
        readonly file: string;
        readonly against: "the planned text" | "the present text";
        readonly match: TextMatch | null;
        readonly previousMatch: TextMatch | null;
    }) | null;
};
export declare const previousInstructionsPath: (home: string) => string;
export declare const updateStatePath: (home: string) => string;
export declare const applyPlan: ({ home, currentFile, publishedFile, publishedSha256, routinesFile, readBackFile }: ApplyPlanRequest, catalogue: InstructionsCatalogue, template: readonly TemplateRoutine[]) => ApplyPlan;
export {};
