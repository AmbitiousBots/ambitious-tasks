import type { LockRow } from "../domain/lock.ts";
import { type Download } from "./install.ts";
import { type RunTool, type RuntimeOutcome } from "./runtime.ts";
export type ModuleState = "installed" | "unchanged" | "reinstalled" | "upgraded" | "failed";
export type SelfcheckState = "ok" | "problems" | "not run";
export type ModuleReport = {
    readonly module: string;
    readonly version: string;
    readonly state: ModuleState;
    readonly selfcheck: SelfcheckState;
    readonly problems: readonly string[];
    readonly runtime?: RuntimeOutcome;
};
export type PinnedRuntimeRequest = {
    readonly module: string;
    readonly runTool: RunTool;
};
export type Runtimes = {
    readonly node: string;
    readonly python: () => string | null;
};
export type SyncRequest = {
    readonly rows: readonly LockRow[];
    readonly home: string;
    readonly sourceFor: (row: LockRow) => Download;
    readonly runtimes: Runtimes;
    readonly environment: Readonly<Record<string, string | undefined>>;
    readonly pinnedRuntime?: PinnedRuntimeRequest;
};
export declare const findPython: () => string | null;
export declare const sync: (request: SyncRequest) => Promise<readonly ModuleReport[]>;
export declare const summaryOf: (reports: readonly ModuleReport[]) => string;
