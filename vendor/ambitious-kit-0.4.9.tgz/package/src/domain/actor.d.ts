export declare const ACTOR_MAX_CHARACTERS = 200;
export declare const ACTOR_RULE = "actor is 1 to 200 Unicode characters, with no control characters or line breaks and no leading or trailing whitespace. Internal spaces are allowed. Nothing is trimmed.";
export declare const actorProblem: (raw: unknown) => string | null;
export declare const parseActor: (raw: unknown) => string;
