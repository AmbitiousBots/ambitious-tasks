import { type Fingerprint, type TextMatch } from "./whitespace.ts";
export type KnownInstructions = Fingerprint & {
    readonly version: number;
};
export type PublishedGrants = {
    readonly version: number;
    readonly grants: readonly string[];
    readonly reasons: Readonly<Record<string, string>>;
    readonly text?: string;
};
export type InstructionsCatalogue = {
    readonly version: number;
    readonly oldestSupported: number;
    readonly text: string;
    readonly known: readonly KnownInstructions[];
    readonly grants: Readonly<Record<string, string>>;
    readonly versions: readonly PublishedGrants[];
};
export type InstructionsProblem = "instructions-out-of-date" | "instructions-custom";
export type InstructionsFinding = {
    readonly state: "current";
    readonly problem: null;
    readonly current: number;
    readonly template: number;
    readonly match: TextMatch;
} | {
    readonly state: "out-of-date";
    readonly problem: "instructions-out-of-date";
    readonly current: number;
    readonly template: number;
    readonly match: TextMatch;
} | {
    readonly state: "out-of-date";
    readonly problem: "instructions-out-of-date";
    readonly current: null;
    readonly template: number;
    readonly match: null;
} | {
    readonly state: "custom";
    readonly problem: "instructions-custom";
    readonly current: number | null;
    readonly template: number;
    readonly match: null;
} | {
    readonly state: "newer";
    readonly problem: null;
    readonly current: number;
    readonly template: number;
    readonly match: null;
};
export type Permission = {
    readonly grant: string;
    readonly permission: string;
    readonly reason: string | null;
};
export type PermissionChange = {
    readonly comparedWith: "the bot's present text" | "the oldest supported text";
    readonly comparison: "more" | "fewer" | "same" | "more and fewer";
    readonly added: readonly Permission[];
    readonly removed: readonly Permission[];
    readonly statement: string;
};
export type UpgradeAuthority = "any request" | "the owner's request";
export type SelfApply = "granted" | "not granted";
export type NewerTemplate = {
    readonly own: string;
    readonly latest: string;
};
export declare const UPGRADE_GRANT = "upgrade-on-any-request";
export declare const SELF_APPLY_GRANT = "verified-self-apply";
export declare const ADDITIONAL_PERMISSIONS = "Applying this text gives the bot these additional permissions:";
export declare const instructionsVersionOf: (folded: string) => number | null;
export declare const classifyInstructions: (folded: string, given: Fingerprint, { version: template, known }: InstructionsCatalogue) => InstructionsFinding;
export declare const needsOwner: (finding: InstructionsFinding) => boolean;
export declare const upgradeAuthority: (finding: InstructionsFinding, { versions }: InstructionsCatalogue) => UpgradeAuthority;
export declare const selfApplyAuthority: (finding: InstructionsFinding, folded: string, catalogue: InstructionsCatalogue) => SelfApply;
export declare const permissionChange: (finding: InstructionsFinding, { version, oldestSupported, grants, versions }: InstructionsCatalogue) => PermissionChange | null;
export declare const instructionsMessage: (finding: InstructionsFinding, proposed: string, change: PermissionChange | null, newer: NewerTemplate | null) => string | null;
export declare const lineDiff: (from: string, to: string) => readonly string[];
export declare const parseInstructionsCatalogue: (value: unknown) => InstructionsCatalogue;
