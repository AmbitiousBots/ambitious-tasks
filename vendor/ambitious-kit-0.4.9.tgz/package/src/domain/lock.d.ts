export type LockRow = {
    readonly module: string;
    readonly version: string;
    readonly url: string;
    readonly sha256: string;
    readonly kind: "mjs" | "pyz";
    readonly asset: string;
    readonly release: string;
    readonly tag: string;
    readonly runtimeSha256?: string;
};
export declare const LOCK_PATTERNS: {
    readonly module: "^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$";
    readonly version: "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)(?:-(?:0|[1-9][0-9]*|[0-9]*[A-Za-z-][0-9A-Za-z-]*)(?:\\.(?:0|[1-9][0-9]*|[0-9]*[A-Za-z-][0-9A-Za-z-]*))*)?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$";
    readonly url: "^https://[^\\s/?#@]+/[^\\s?#]+\\.(?:mjs|pyz)$";
    readonly sha256: "^[0-9a-f]{64}$";
    readonly runtimeSha256: "^[0-9a-f]{64}$";
};
export declare const parseLock: (value: unknown) => readonly LockRow[];
export declare const isNewerVersion: (candidate: string, than: string) => boolean;
