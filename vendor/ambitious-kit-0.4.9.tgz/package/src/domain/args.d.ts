export type Flags = {
    readonly in: string | null;
    readonly db: string | null;
    readonly now: string | null;
    readonly seed: string | null;
    readonly help: boolean;
};
export type ParsedArgs = {
    readonly words: readonly string[];
    readonly flags: Flags;
    readonly problems: readonly string[];
};
export declare const FLAG_USAGE = "[--in file] [--db path] [--now ISO8601] [--seed int] [--json] [--help]";
export declare const parseArgs: (argv: readonly string[]) => ParsedArgs;
