import type { InstructionsFinding, PermissionChange } from "./instructions.ts";
import type { RoutineFinding, RoutineOffer } from "./routines.ts";
import type { TextMatch } from "./whitespace.ts";
export type PlanAction = "apply" | "apply-published-and-archive" | "no-change" | "blocked";
export type BlockReason = "published-checksum-mismatch" | "release-checksum-mismatch" | "downgrade" | "text-not-in-verified-installer";
export type ReleaseMatch = TextMatch | "mismatch";
export type PlanTrust = {
    readonly suppliedChecksum: "match" | "mismatch";
    readonly release: ReleaseMatch;
    readonly downgrade: boolean;
    readonly publishedVersion: number | null;
    readonly installerVersion: number;
    readonly blocked: readonly BlockReason[];
};
export type MergeOutcome = "not needed" | "merged" | "conflicts" | "unknown base";
export type RoutinePlan = RoutineFinding & {
    readonly action: PlanAction;
    readonly archive: RoutineOffer | null;
    readonly sameName: number;
    readonly held?: true;
};
export type RestoredOver = {
    readonly version: number | null;
    readonly sha256: string;
};
export declare const SELF_WRITE: {
    readonly instructions: {
        readonly tool: "UpdateProfile";
        readonly field: "description";
        readonly target: "this bot only";
    };
    readonly routines: {
        readonly tool: "UpdateRoutine";
        readonly field: "prompt";
        readonly target: "this bot's own routines only";
    };
};
export declare const overallAction: (actions: readonly PlanAction[]) => PlanAction;
export declare const publishedTrust: (suppliedChecksumMatches: boolean, published: InstructionsFinding, declared: number | null, current: InstructionsFinding) => PlanTrust;
export declare const blockMessage: (reason: BlockReason, { publishedVersion, installerVersion }: PlanTrust, current: InstructionsFinding) => string;
export type FailedApply = {
    readonly version: number | null;
    readonly sha256: string;
    readonly kind: string | null;
    readonly attempts: number | null;
    readonly routine: {
        readonly name: string;
        readonly sha256: string;
    } | null;
};
export type Truncated = {
    readonly version: number;
};
export declare const truncatedFrom: (current: InstructionsFinding, folded: string, published: readonly {
    readonly version: number;
    readonly folded: string;
}[]) => Truncated | null;
export declare const retryAllowed: ({ kind, attempts }: FailedApply) => boolean;
export declare const instructionsAction: (current: InstructionsFinding, merge: MergeOutcome, mergedIsCurrent: boolean, damaged?: boolean) => PlanAction;
export declare const heldReason: ({ version, kind }: FailedApply, target: number, what?: string) => string;
export declare const damagedReason: ({ version }: Truncated, target: number, repairs: boolean) => string;
export declare const restoredReason: ({ version }: RestoredOver, target: number) => string;
export declare const notGrantedReason: (target: number) => string;
export declare const instructionsReason: (action: PlanAction, current: InstructionsFinding, merge: MergeOutcome, baseVersion: number | null, kept: number, conflicts: number) => string;
export declare const planRoutine: (finding: RoutineFinding, mine: RoutineOffer | null, sameName: number, held?: boolean) => RoutinePlan;
export declare const routineReason: (plan: RoutinePlan) => string | null;
export declare const updateStatement: ({ comparedWith, added, removed }: PermissionChange, keepsLocalChanges: boolean) => string;
