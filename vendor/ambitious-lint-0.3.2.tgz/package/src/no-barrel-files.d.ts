import type { Rule } from "eslint";
export declare const noBarrelFiles: Rule.RuleModule;
