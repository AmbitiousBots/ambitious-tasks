import type { IConfiguration, IForbiddenRuleType } from "dependency-cruiser";
export declare const forbidden: IForbiddenRuleType[];
export declare const config: IConfiguration;
