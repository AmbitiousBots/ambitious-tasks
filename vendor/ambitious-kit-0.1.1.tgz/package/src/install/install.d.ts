export type AssetKind = "mjs" | "pyz";
export type Download = (fileName: string) => Promise<Uint8Array>;
export type InstallRequest = {
    readonly module: string;
    readonly version: string;
    readonly kind: AssetKind;
    readonly home: string;
    readonly download: Download;
};
export type InstallAction = "installed" | "replaced" | "relinked" | "unchanged";
export type InstallOutcome = {
    readonly action: InstallAction;
    readonly asset: string;
    readonly path: string;
    readonly link: string;
    readonly sha256: string;
};
export declare const SUMS_FILE = "SHA256SUMS";
export declare const parseSums: (text: string) => ReadonlyMap<string, string>;
export declare const install: ({ module, version, kind, home, download }: InstallRequest) => Promise<InstallOutcome>;
