import type { Migration } from "../domain/migrations.ts";
export type Embedded = {
    readonly module: string;
    readonly version: string;
    readonly migrations: readonly Migration[];
};
export declare const embedded: () => Embedded;
