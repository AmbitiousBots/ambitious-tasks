export declare const contractTests: (binPath: string) => void;
