export declare const AGENT_DATA_ROOT = "/home/box/agent-data";
export declare const DEFAULT_AMBITIOUS_HOME = "/workspace/ambitious";
export declare const refuseAgentData: (path: string) => string;
export declare const ambitiousHome: (environment: Readonly<Record<string, string | undefined>>) => string;
